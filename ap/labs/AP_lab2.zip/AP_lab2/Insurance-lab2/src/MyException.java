@SuppressWarnings("serial")
public class MyException extends Exception {
	String message;
	MyException(String msg)
	{
		this.message = msg;
	}
}

@SuppressWarnings("serial")
class NoPolicyException extends MyException {

	NoPolicyException()
	{
		super("Sorry, this vehicle does not have a policy!");
	}
}

@SuppressWarnings("serial")
class ExpiredPolicyException extends MyException {
	ExpiredPolicyException() 
	{
		super("The poliicy for this vehicle has expired!");
	}
}
