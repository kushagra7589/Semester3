public class Vehicle {
	String owner_name;
	int number_of_wheels;
	protected int damage;
	String model_name;
	PackagePolicy pp;
	ThirdPartyPolicy tp;
	
	Vehicle()
	{
		this.owner_name = null;
		this.number_of_wheels = 0;
	}
	
	Vehicle(String some_name, int some_num, String model)
	{
		this.number_of_wheels = some_num;
		this.owner_name = some_name;
		this.model_name = model;
	}
	
	void set_damage(int dam)
	{
		this.damage = dam;
	}
	
	int get_damage()
	{
		return this.damage;
	}
}

class Engine_powered extends Vehicle {
	Engine_powered()
	{
		super();
	}
	Engine_powered(String some_name, int some_num, String choose_policy, String expiry, String model, int pno)
	{
		super(some_name, some_num, model);
		System.out.print("Owner Name: ");
		System.out.println(this.owner_name);
		System.out.print("Model: ");
		System.out.println(this.model_name);
		System.out.print("Number of wheels: ");
		System.out.println(this.number_of_wheels);
		if(choose_policy.equals("pp")) {
			this.pp = new PackagePolicy(expiry, pno);
			this.tp = null;
		}
		else if(choose_policy.equals("tp")) {
			this.pp = null;
			this.tp = new ThirdPartyPolicy(expiry, pno);
		}
		else {
			this.pp = null;
			this.tp = null;
		}
		System.out.println("Policy Class: " + this.get_policy_class());
		System.out.println("----------------------------------");
	}
	String get_policy_class()
	{
		if(this.tp == null)
		{
			return "Package Policy";
		}
		else if(this.pp == null)
		{
			return "Third Party Policy";
		}
		else
		{
			return "No Policy";
		}
	}
}

class Manual extends Vehicle {
	Manual()
	{
		super();
		pp = null;
		tp = null;
	}
	Manual(String some_name, int some_num, String model)
	{
		super(some_name, some_num, model);
		pp = null;
		tp = null;
		System.out.print("Owner Name: ");
		System.out.println(this.owner_name);
		System.out.print("Model: ");
		System.out.println(this.model_name);
		System.out.print("Number of wheels: ");
		System.out.println(this.number_of_wheels);
		System.out.println("Policy Class: " + this.get_policy_class());
		System.out.println("----------------------------------");
	}
	String get_policy_class()
	{
		return "No policy";
	}
}

class Two_wheeler extends Engine_powered {
	Two_wheeler()
	{
		super();
	}
	Two_wheeler(String some_name, String choose_policy, String expiry, String model, int pno)
	{
		super(some_name, 2, choose_policy, expiry, model, pno);
	}
}

class Four_wheeler extends Engine_powered {
	Four_wheeler()
	{
		super();
	}
	Four_wheeler(String some_name, String choose_policy, String expiry, String model, int pno)
	{
		super(some_name, 4, choose_policy, expiry, model, pno);
	}
}

class HeroHonda extends Two_wheeler {
	
	HeroHonda()
	{
		super();
	}
	
	HeroHonda(String owner_name, String choose_policy, String expiry, int pno)
	{
		super(owner_name, choose_policy, expiry, "Hero Honda", pno);
	}
}

class Yamaha extends Two_wheeler {
	Yamaha()
	{
		super();
	}
	Yamaha(String owner_name, String choose_policy, String expiry, int pno)
	{
		super(owner_name, choose_policy, expiry, "Yamaha", pno);
	}
}
 
class i10 extends Four_wheeler {
	i10()
	{
		super();
	}
	i10(String owner_name, String choose_policy, String expiry, int pno)
	{
		super(owner_name, choose_policy, expiry, "i10", pno);
	}
}

class Swift extends Four_wheeler {
	Swift()
	{
		super();
	}
	Swift(String owner_name, String choose_policy, String expiry, int pno)
	{
		super(owner_name, choose_policy, expiry, "Swift", pno);
	}
}

class Cycle extends Manual {
	Cycle()
	{
		super();
	}
	Cycle(String owner_name, String model)
	{
		super(owner_name, 2, model);
	}
}

class Firefox extends Cycle {
	Firefox()
	{
		super();
	}
	Firefox(String owner_name)
	{
		super(owner_name, "Firefox");
	}
}

class Avon extends Cycle {
	Avon()
	{
		super();
	}
	Avon(String owner_name)
	{
		super(owner_name, "Avon");
	}
}

