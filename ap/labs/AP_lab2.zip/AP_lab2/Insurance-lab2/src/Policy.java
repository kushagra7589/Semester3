import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Policy {
	Date expiryDate;
	int PolicyNumber;
	Policy()
	{
		this.expiryDate = null;
		this.PolicyNumber = 0;
	}
	Policy(String expiry, int pno)
	{
		this.PolicyNumber = pno;
		SimpleDateFormat input_date = new SimpleDateFormat("dd/MM/yyyy");
		try
		{
			this.expiryDate = input_date.parse(expiry);
		}
		catch(ParseException e)
		{
			this.expiryDate = null;
			System.out.println("Unparseable date format");
		}
	}
	void DisplayExpiry()
	{
		SimpleDateFormat output_date = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Expiry Date: " + output_date.format(this.expiryDate));
	}
	
	boolean isExpired()
	{
		Date current = new Date();
		return current.after(expiryDate);
	}
}

class ThirdPartyPolicy extends Policy {
	private int third_party_damage;
	ThirdPartyPolicy()
	{
		super();
		third_party_damage = 0;
	}
	ThirdPartyPolicy(String expiry, int pno)
	{
		super(expiry, pno);
		this.third_party_damage = 0;
		System.out.println("Policy Number: " + this.PolicyNumber);
		this.DisplayExpiry();
	}
	void set_damage(int damage)
	{
		this.third_party_damage = damage;
	}
	int get_damage()
	{
		return this.third_party_damage;
	}
	void InCollision()
	{
		this.third_party_damage = (this.third_party_damage)/5;
	}
}

class PackagePolicy extends Policy {
	private int self_damage;
	private int third_party_damage;
	PackagePolicy()
	{
		super();
		this.self_damage = 0;
		this.third_party_damage = 0;
	}
	PackagePolicy(String expiry, int pno)
	{
		super(expiry, pno);
		this.self_damage = 0;
		this.third_party_damage = 0;
		System.out.println("Policy Number: " + this.PolicyNumber);
		this.DisplayExpiry();
	}
	void set_damage(int damage_self, int damage_other)
	{
		this.self_damage = damage_self;
		this.third_party_damage = damage_other;
	}
	void InCollision()
	{
		this.self_damage = this.self_damage/2;
		this.third_party_damage = (this.third_party_damage)/5;
		
	}
	int get_self_damage()
	{
		return this.self_damage;
	}
	int get_third_party_damage()
	{
		return this.third_party_damage;
	}
}
