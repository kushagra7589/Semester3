import java.util.Random;

public class Collision {

	static void assignDamage(Vehicle V)
	{
		Random randomno = new Random();
		int dam = randomno.nextInt(10000);
		V.set_damage(dam);
	}
	
	static void doSettlement(int self_index, int other_index, Vehicle[] list_V)
	{
		try {
			if(list_V[self_index].pp == null  && list_V[self_index].tp == null) {
				NoPolicyException e = new NoPolicyException();
				throw e;
			}
			else if(list_V[self_index].pp == null) {
				if(list_V[self_index].tp.isExpired()) {
					ExpiredPolicyException e = new ExpiredPolicyException();
					throw e;
				}
				else {
					list_V[self_index].tp.set_damage(list_V[other_index].get_damage());
					list_V[self_index].tp.InCollision();
					list_V[other_index].set_damage(list_V[self_index].tp.get_damage());
				}
			}
			else if(list_V[self_index].tp == null) {
				if(list_V[self_index].pp.isExpired()) {
					ExpiredPolicyException e = new ExpiredPolicyException();
					throw e;
				}
				else {
					list_V[self_index].pp.set_damage(list_V[other_index].get_damage(), list_V[other_index].get_damage());
					list_V[self_index].pp.InCollision();
					list_V[other_index].set_damage(list_V[self_index].pp.get_third_party_damage());
					list_V[self_index].set_damage(list_V[self_index].pp.get_self_damage());
				}
			}
			System.out.println("Settlement Details");
			System.out.println("Oncoming damage status: " + list_V[other_index].get_damage());
			System.out.println("Self damage status: " + list_V[self_index].get_damage());
		}
		catch(ExpiredPolicyException epe) {
			System.out.println(epe.message);
		}
		catch(NoPolicyException npe) {
			System.out.println(npe.message);
		}
	}
	
	static void collide(int self, int other, Vehicle[] list_V)
	{
		System.out.println("I am " + list_V[self].model_name + ", owned by " + list_V[self].owner_name + " collided with " + list_V[other].model_name + ", owned by " + list_V[other].owner_name);
		System.out.println("Self damage: " + list_V[self].get_damage());
		System.out.println("Oncoming damage: " + list_V[other].get_damage());
		doSettlement(self, other, list_V);
		System.out.println("-----------------------------------------");
	}
	
	public static void main(String args[])
	{
		HeroHonda bike1;
		bike1 = new HeroHonda("ABC", "tp", "12/08/2018", 1);
		assignDamage(bike1);
		Yamaha bike2 = new Yamaha("XYZ", "pp", "12/08/2016", 2);
		assignDamage(bike2);
		i10 car1 = new i10("PQR", "pp", "17/01/2017", 3);
		assignDamage(car1);
		Swift car2 = new Swift("LMN", "pp", "10/09/2013", 4);
		assignDamage(car2);
		Firefox cycle1 = new Firefox("DEF");
		assignDamage(cycle1);
		Avon cycle2 = new Avon("JKL");
		assignDamage(cycle2);
		
		Vehicle[] list_of_vehicles = new Vehicle[]{bike1, bike2, car1, car2, cycle1, cycle2};
		for(int i=0; i<6; i++)
		{
			for(int j=0; j<6; j++)
			{
				if(i != j) {
					collide(i, j, list_of_vehicles);
				}
			}
		}
	}
}
