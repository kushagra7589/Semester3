package complex_number;

public class IncompatibleTypeException extends Exception{
	
	public IncompatibleTypeException()
	{
		super();
	}
	public String toString()
	{
		return "The types are incompatible";
	}
}
