package complex_number;

public class Complex {
	private final Integer real;
	private final Integer imag;
	public Complex(Integer a, Integer b){ real = a; imag = b; }
	
	Integer getReal(){ return real; }
	Integer getImag(){ return imag; }
	
	Complex Add(Complex a, Complex b)
	{
		Complex ans = new Complex(a.getReal() + b.getReal(), a.getImag() + b.getImag());
		return ans;
	}
	
	Complex Sub(Complex a, Complex b)
	{
		Complex ans = new Complex(a.getReal()- b.getReal(), a.getImag() - b.getImag());
		return ans;
	}
	
	Double Modulus(Complex a)
	{
		return Math.sqrt(a.getReal()*a.getReal() + a.getImag()*a.getImag());
	}
	
	Complex Conjugate(Complex a)
	{
		return new Complex(a.getReal(), -a.getImag());
	}
	
	Complex Multiply(Complex a, Complex b)
	{
		Integer r = a.getReal()*b.getReal() - a.getImag()*b.getImag() ;
		Integer i = a.getReal()*b.getImag() + a.getImag()*b.getReal() ;
		return new Complex(r, i);
	}
	
	public String toString()
	{
		return real + " + " + imag + "i";
	}
		
}
