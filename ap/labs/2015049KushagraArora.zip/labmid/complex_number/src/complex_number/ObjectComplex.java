package complex_number;

public class ObjectComplex {
	private Object real;
	private Object imag;
	public ObjectComplex(Object r, Object i){ real = r ; imag = i; } //to inhibit inheritance
	
	Object getReal(){ return real; }
	Object getImag(){ return imag; }
	
	ObjectComplex Add(ObjectComplex a, ObjectComplex b) throws IncompatibleTypeException
	{
		if(a.getReal() instanceof Integer && a.getImag() instanceof Integer && b.getReal() instanceof Integer && b.getImag() instanceof Integer)
		{
			ObjectComplex ans = new ObjectComplex((Integer)a.getReal() + (Integer)b.getReal(), (Integer)a.getImag() + (Integer)b.getImag() );
			return ans;
		}
		else if(a.getReal() instanceof Double && a.getImag() instanceof Double && b.getReal() instanceof Double && b.getImag() instanceof Double)
		{
			ObjectComplex ans = new ObjectComplex((Double)a.getReal() + (Double)b.getReal(), (Double)a.getImag() + (Double)b.getImag() );
			return ans;
		}
		else if(a.getReal() instanceof Float && a.getImag() instanceof Float && b.getReal() instanceof Float && b.getImag() instanceof Float)
		{
			ObjectComplex ans = new ObjectComplex((Float)a.getReal() + (Float)b.getReal(), (Float)a.getImag() + (Float)b.getImag() );
			return ans;
		}
		else
		{
			IncompatibleTypeException e = new IncompatibleTypeException();
			throw e;
		}
	}
	
	ObjectComplex Subtract(ObjectComplex a, ObjectComplex b) throws IncompatibleTypeException
	{
		if(a.getReal() instanceof Integer && a.getImag() instanceof Integer && b.getReal() instanceof Integer && b.getImag() instanceof Integer)
		{
			ObjectComplex ans = new ObjectComplex((Integer)a.getReal() - (Integer)b.getReal(), (Integer)a.getImag() - (Integer)b.getImag() );
			return ans;
		}
		else if(a.getReal() instanceof Double || a.getImag() instanceof Double || b.getReal() instanceof Double || b.getImag() instanceof Double)
		{
			ObjectComplex ans = new ObjectComplex((Double)a.getReal() - (Double)b.getReal(), (Double)a.getImag() - (Double)b.getImag() );
			return ans;
		}
		else if(a.getReal() instanceof Float && a.getImag() instanceof Float && b.getReal() instanceof Float && b.getImag() instanceof Float)
		{
			ObjectComplex ans = new ObjectComplex((Float)a.getReal() - (Float)b.getReal(), (Float)a.getImag() - (Float)b.getImag() );
			return ans;
		}
		else
		{
			IncompatibleTypeException e = new IncompatibleTypeException();
			throw e;
		}
	}
	
	Double Absolute(ObjectComplex a)
	{
		if(a.getReal() instanceof Integer)
		{
			Integer r = (Integer)a.getReal();
			Integer i = (Integer)a.getImag();
			return Math.sqrt(i*i + r*r);
		}
		else if(a.getReal() instanceof Float)
		{
			Float r = (Float)a.getReal();
			Float i = (Float)a.getImag();
			return Math.sqrt(i*i + r*r);
		}
		else if(a.getReal() instanceof Double)
		{
			Double r = (Double)a.getReal();
			Double i = (Double)a.getImag();
			return Math.sqrt(i*i + r*r);
		}
		else
		{
			return 0.0;
		}
	}
	
	ObjectComplex Conjugate(ObjectComplex a) throws IncompatibleTypeException
	{
		if(a.getReal() instanceof Integer && a.getImag() instanceof Integer)
		{
			return new ObjectComplex((Integer)a.getReal(), Integer.valueOf(0) - (Integer)a.getImag());
		}
		else if (a.getReal() instanceof Double && a.getImag() instanceof Double)
		{
			return new ObjectComplex((Double)a.getReal(), Double.valueOf(0) - (Double)a.getImag());	
		}
		else if(a.getReal() instanceof Float && a.getImag() instanceof Float)
		{
			return new ObjectComplex((Float)a.getReal(), Float.valueOf(0) - (Float)a.getImag());
		}
		else
		{
			IncompatibleTypeException e = new IncompatibleTypeException();
			throw e;
		}
	}
	
	ObjectComplex Multiply(ObjectComplex a, ObjectComplex b) throws IncompatibleTypeException
	{
		if(a.getReal() instanceof Integer && a.getImag() instanceof Integer && b.getReal() instanceof Integer && b.getImag() instanceof Integer)
		{
			Integer r1 = (Integer)a.getReal();
			Integer r2 = (Integer)b.getReal();
			Integer i1 = (Integer)a.getImag();
			Integer i2 = (Integer)b.getImag();
			ObjectComplex ans = new ObjectComplex(r1*r2 - i1*i2, r1*i2 + i1*r2);
			return ans;
		}
		else if(a.getReal() instanceof Double || a.getImag() instanceof Double || b.getReal() instanceof Double || b.getImag() instanceof Double)
		{
			Double r1 = (Double)a.getReal();
			Double r2 = (Double)b.getReal();
			Double i1 = (Double)a.getImag();
			Double i2 = (Double)b.getImag();
			ObjectComplex ans = new ObjectComplex(r1*r2 - i1*i2, r1*i2 + i1*r2);
			return ans;
		}
		else if(a.getReal() instanceof Float && a.getImag() instanceof Float && b.getReal() instanceof Float && b.getImag() instanceof Float)
		{
			Float r1 = (Float)a.getReal();
			Float r2 = (Float)b.getReal();
			Float i1 = (Float)a.getImag();
			Float i2 = (Float)b.getImag();
			ObjectComplex ans = new ObjectComplex(r1*r2 - i1*i2, r1*i2 + i1*r2);
			return ans;
		}
		else
		{
			IncompatibleTypeException e = new IncompatibleTypeException();
			throw e;
		}
	}
	
	public String toString()
	{
		return real + " + " + imag + "i";
	}
	
}
