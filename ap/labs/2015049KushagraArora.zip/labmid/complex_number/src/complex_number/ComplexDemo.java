package complex_number;
import java.util.*;
public class ComplexDemo {
	public static void main(String args[])
	{
		System.out.println("Working with Complex class of Integers - ");
		Complex z = new Complex(2, 3);
		System.out.println("z = " + z);
		Complex w = new Complex(4, 5);
		System.out.println("w = " + w);
		z = z.Add(z, w);
		System.out.println("z = z + w = " + z);
		z = z.Sub(z, w);
		System.out.println("z = z - w = " + z);
		z = z.Multiply(z, w);
		System.out.println("z = z * w = " + z);
		Complex zbar = z.Conjugate(z);
		System.out.println("Conjugate of z = " + zbar);
		Double mod = z.Modulus(z);
		System.out.println("Absolute value of z = " + mod);
		System.out.println("----------------------------------------------------------------------------");
		System.out.println();
		System.out.println("Working with Complex class of Arbitrary types using Object Class - ");
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter the real part of Integer complex number 1: ");
		Integer ri1 = reader.nextInt();
		System.out.println("Enter the imaginary part of Integer complex number 1: ");
		Integer ii1 = reader.nextInt();
		System.out.println("Enter the real part of Integer complex number 2: ");
		Integer ri2 = reader.nextInt();
		System.out.println("Enter the imaginary part of Integer complex number 2: ");
		Integer ii2 = reader.nextInt();
		ObjectComplex a = new ObjectComplex(ri1, ii1);
		ObjectComplex b = new ObjectComplex(ri2, ii2);
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		try{
			a = a.Add(a, b);
			System.out.println("a = a + b = " + a);
			a = a.Subtract(a, b);
			System.out.println("a = a - b = " + a);
			a = a.Multiply(a, b);
			System.out.println("a = a * b = " + a);
			ObjectComplex conj = a.Conjugate(a);
			System.out.println("The conjugate of a is : " + conj);
			Double modi = a.Absolute(a);
			System.out.println("The absolute value of a is : " + modi);
		}
		catch(IncompatibleTypeException e)
		{
			System.out.println(e);
		}
		System.out.println("Enter the real part of the Float complex number 1: ");
		Float rf1 = reader.nextFloat();
		System.out.println("Enter the imaginary part of the Float complex number 1: ");
		Float iff1 = reader.nextFloat();
		a = new ObjectComplex(rf1, iff1);
		System.out.println("a = " + a);
		System.out.println("Enter the real part of the Float complex number 2: ");
		Float rf2 = reader.nextFloat();
		System.out.println("Enter the imaginary part of the Float complex number 2: ");
		Float iff2 = reader.nextFloat();
		b = new ObjectComplex(rf2, iff2);
		System.out.println("b = " + b);
		try{
			a = a.Add(a, b);
			System.out.println("a = a + b = " + a);
			a = a.Subtract(a, b);
			System.out.println("a = a - b = " + a);
			a = a.Multiply(a, b);
			System.out.println("a = a * b = " + a);
			ObjectComplex conj = a.Conjugate(a);
			System.out.println("The conjugate of a is : " + conj);
			Double modi = a.Absolute(a);
			System.out.println("The absolute value of a is : " + modi);
		}
		catch(IncompatibleTypeException e)
		{
			System.out.println(e);
		}
		
		System.out.println("Enter the real part of the Double complex number 1: ");
		Double rd1 = reader.nextDouble();
		System.out.println("Enter the imaginary part of the Double complex number 1: ");
		Double id1 = reader.nextDouble();
		a = new ObjectComplex(rd1, id1);
		System.out.println("a = " + a);
		System.out.println("Enter the real part of the Double complex number 2: ");
		Double rd2 = reader.nextDouble();
		System.out.println("Enter the imaginary part of the Double complex number 2: ");
		Double id2 = reader.nextDouble();
		b = new ObjectComplex(rd2, id2);
		System.out.println("b = " + b);
		try{
			a = a.Add(a, b);
			System.out.println("a = a + b = " + a);
			a = a.Subtract(a, b);
			System.out.println("a = a - b = " + a);
			a = a.Multiply(a, b);
			System.out.println("a = a * b = " + a);
			ObjectComplex conj = a.Conjugate(a);
			System.out.println("The conjugate of a is : " + conj);
			Double modi = a.Absolute(a);
			System.out.println("The absolute value of a is : " + modi);
		}
		catch(IncompatibleTypeException e)
		{
			System.out.println(e);
		}
		System.out.println("----------------------------------------------------------------------------");
		System.out.println();
		
		System.out.println("Working with generic class of Complex Numbers : ");
		System.out.println("Enter the real part of Integer complex number 1: ");
		Integer rig1 = reader.nextInt();
		System.out.println("Enter the imaginary part of Integer complex number 1: ");
		Integer iig1 = reader.nextInt();
		System.out.println("Enter the real part of Integer complex number 2: ");
		Integer rig2 = reader.nextInt();
		System.out.println("Enter the imaginary part of Integer complex number 2: ");
		Integer iig2 = reader.nextInt();
		GenericComplex<Integer> c = new GenericComplex<Integer>(rig1, iig1);
		GenericComplex<Integer> d = new GenericComplex<Integer>(rig2, iig2);
		System.out.println("c = " + c);
		System.out.println("d = " + d);
		GenericComplex<Double> result;
		result = c.Add(c, d);
		System.out.println("c + d = " + result);
		result = c.Sub(c, d);
		System.out.println("c - d = " + result);
		result = c.Multiply(c, d);
		System.out.println("c * d = " + result);
		GenericComplex<Integer> conj = c.Conjugate(c);
		System.out.println("The conjugate of c is : " + conj);
		Double modi = c.Absolute(c);
		System.out.println("The absolute value of c is : " + modi);
	
		System.out.println("Enter the real part of Float complex number 1: ");
		Float rfg1 = reader.nextFloat();
		System.out.println("Enter the imaginary part of Float complex number 1: ");
		Float ifg1 = reader.nextFloat();
		System.out.println("Enter the real part of Float complex number 2: ");
		Float rfg2 = reader.nextFloat();
		System.out.println("Enter the imaginary part of Float complex number 2: ");
		Float ifg2 = reader.nextFloat();
		GenericComplex<Float> e = new GenericComplex<Float>(rfg1, ifg1);
		GenericComplex<Float> f = new GenericComplex<Float>(rfg2, ifg2);
		System.out.println("e = " + e);
		System.out.println("f = " + f);
		result = e.Add(e, f);
		System.out.println("e + f = " + result);
		result = e.Sub(e, f);
		System.out.println("e - f = " + result);
		result = e.Multiply(e, f);
		System.out.println("e * f = " + result);
		GenericComplex<Float> conjf = e.Conjugate(e);
		System.out.println("The conjugate of e is : " + conjf);
		modi = e.Absolute(e);
		System.out.println("The absolute value of e is : " + modi);

		System.out.println("Enter the real part of Double complex number 1: ");
		Double rdg1 = reader.nextDouble();
		System.out.println("Enter the imaginary part of Double complex number 1: ");
		Double idg1 = reader.nextDouble();
		System.out.println("Enter the real part of Double complex number 2: ");
		Double rdg2 = reader.nextDouble();
		System.out.println("Enter the imaginary part of Double complex number 2: ");
		Double idg2 = reader.nextDouble();
		GenericComplex<Double> g = new GenericComplex<Double>(rdg1, idg1);
		GenericComplex<Double> h = new GenericComplex<Double>(rdg2, idg2);
		System.out.println("g = " + g);
		System.out.println("h = " + h);
		result = g.Add(g, h);
		System.out.println("g + h = " + result);
		result = g.Sub(g, h);
		System.out.println("g - h = " + result);
		result = g.Multiply(g, h);
		System.out.println("g * h = " + result);
		GenericComplex<Double> conjd = g.Conjugate(g);
		System.out.println("The conjugate of g is : " + conjd);
		modi = g.Absolute(g);
		System.out.println("The absolute value of g is : " + modi);
		System.out.println("----------------------------------------------------------------------------");
		System.out.println();
		reader.close();
	}
}
