package complex_number;

public class GenericComplex<T extends Number> {
	private T real;
	private T imag;
	
	public GenericComplex(T r, T i)
	{
		real = r;
		imag = i;
	}
	
	T getReal(){ return real; }
	T getImag(){ return imag; }
	
	public GenericComplex<Double> Add(GenericComplex<T> a, GenericComplex<T> b)
	{
		GenericComplex<Double> ans = new GenericComplex<Double>((Double)a.getReal().doubleValue() + (Double)b.getReal().doubleValue(), (Double)a.getImag().doubleValue() + b.getImag().doubleValue());
		return ans;
	}
	
	public GenericComplex<Double> Sub(GenericComplex<T> a, GenericComplex<T> b)
	{
		GenericComplex<Double> ans = new GenericComplex<Double>((Double)a.getReal().doubleValue() - (Double)b.getReal().doubleValue(), (Double)a.getImag().doubleValue() - b.getImag().doubleValue());
		return ans;
	}
	
	public GenericComplex<Double> Multiply(GenericComplex<T> a, GenericComplex<T> b)
	{
		Double r1 = (Double)a.getReal().doubleValue();
		Double i1 = (Double)a.getImag().doubleValue();
		Double r2 = (Double)b.getReal().doubleValue();
		Double i2 = (Double)b.getImag().doubleValue();
		GenericComplex<Double> ans = new GenericComplex<Double>(r1*r2 - i1*i2, r1*i2 + r2*i1);
		return ans;
	}
	
	public GenericComplex<T> Conjugate(GenericComplex<T> a)
	{
		 GenericComplex<T> ans = new GenericComplex(a.getReal(), 0-a.getImag().doubleValue());
		 return ans;
	}
	
	public Double Absolute(GenericComplex<T> a)
	{
		Number r = (Number)a.getReal();
		Number i = (Number)a.getImag();
		Double ans = Math.sqrt(r.doubleValue()*r.doubleValue() + i.doubleValue()*i.doubleValue());
		return ans;
	}
	
	public String toString()
	{
		return real + " + " + imag + "i";
	}
	
}
