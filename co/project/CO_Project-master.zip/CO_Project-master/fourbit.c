#include <wiringPi.h>
#include <lcd.h>
//USE WIRINGPI PIN NUMBERS
#define LCD_RS  25               //Register select pin
#define LCD_E   24               //Enable Pin
#define LCD_D4  23               //Data pin 4
#define LCD_D5  22               //Data pin 5
#define LCD_D6  21               //Data pin 6
#define LCD_D7  29               //Data pin 7

#include <stdio.h>
#include <stdlib.h> // For exit() function

int main()
{

    char s[1000];
	int c,i;
	i = 0;
    FILE *fptr;
	fptr = fopen("file1.txt", "r");
    if(!fptr)
	return 0;
	
	fscanf(fptr, "%[^\n]", s);
    	fclose(fptr);
	

//   char c[100] = "abc";
 
// printf(s);
 int lcd;
    wiringPiSetup();
    lcd = lcdInit (2, 16, 4, LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7, 0, 0, 0, 0);
 lcdClear(lcd);  
    lcdPuts(lcd, s);
	sleep(3);
	lcdClear(lcd);
	lcdPuts(lcd, "card read");
    return 0;
}
